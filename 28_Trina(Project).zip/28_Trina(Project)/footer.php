<div class="footer">
			Developed and maintained by _Trina_. &copy; 2024
		</div>
	</body>
</html>
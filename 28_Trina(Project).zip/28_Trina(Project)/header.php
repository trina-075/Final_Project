
<html lang="en">
	<head>
	<title> Home</title>
	<link rel="stylesheet" href="style.css">

	</head>
	<body>

		<div class="header">
		   <h1>UNIVERSITY OF BARISHAL</h1>
		</div>

		<div class="nav">
		  <a href="index.php">About</a>
		  <a href="department.php">Departments</a>
		  <a href="application.php">Apply Online</a>
		</div>
		
		
		
		
<?php
	include "header.php";
	include "dbconnect.php";

	$sql = "SELECT * FROM applicant";
	$result = $conn->query($sql);
?>

<h1 align="center">Applicants</h1>
<table>
	<tr>
		<th>SL</th>
		<th>Applicant Name</th>
		
		<th>Phone</th>
		<th>Email</th>
		<th>Date of Birth</th>
		<th>Department</th>
		<th>Edit</th>
		<th>Delete</th>
	</tr>
	<?php
		while($row=$result->fetch_assoc()){
			$id=$row["id"];
			echo "<tr>"; 
			echo "<td>".$row["id"] ."</td>";	
			echo "<td>".$row["name"] ."</td>";	
	
			echo "<td>". $row["phone"]."</td>";	
			echo "<td>". $row["email"]."</td>";	
			echo "<td>". $row["dob"]."</td>";	
			echo "<td>". $row["department"]."</td>";
echo "<td>"."<a href='update.php?editid=$id'>Edit</a>"."</td>";
		echo "<td>"."<a href='delete.php?delid=$id'>Delete</a>"."</td>";			
			echo "</tr>"; 
		}
	
	?>
			
</table>
		
<?php
	include "footer.php";
?>		



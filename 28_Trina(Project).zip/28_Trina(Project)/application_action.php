<?php
	include "dbconnect.php";
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		$name=$_POST["name"];
		
		$phon=$_POST["phone"];
		$email=$_POST["email"];
		$dob=$_POST["dob"];
		$departments=$_POST["departments"];
		
		$sql="INSERT INTO applicant(id, name,  phone, email, dob,department)
		values(NULL, '$name', '$phon', '$email','$dob','$departments')";
		$result=$conn->query($sql);
		if($result)
		{
			//echo "Success";
			header("Location:applicant_list.php");
		}
		else
		{
			echo "Application failed";
		}
	}
	
?>
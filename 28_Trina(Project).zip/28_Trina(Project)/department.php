<?php 
include "header.php";
include "dbconnect.php";

$sql = "SELECT * FROM departments";
$result = $conn->query($sql);


$conn->close();
?>


<html>
<head>
<title>department</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<h1 align="center">Department</h1>
<table>
<tr>
<th> ID </th>
<th> Department Name</th>
<th>Available Seats</th>
<th>Number of Teachers</th>
<th>Number of Classrooms</th>

</tr>
			
<?php 
if ($result->num_rows > 0) 
{
while($row = $result->fetch_assoc())
{ 
echo "<tr>";
echo "<td>". $row["id"]."</td>";
echo "<td>". $row["name"]."</td>";
echo "<td>". $row["available_seats"]."</td>";

echo "<td>". $row["number_of_teachers"]."</td>";
echo "<td>". $row["number_of_class_rooms"]."</td>";

echo "</tr>";
}
}
else echo "No results";
		
?>
			
</table>
		
<?php
	include "footer.php";
?>


<?php
	include "header.php";
	
	
	
	
?>

	<div class="announce">
		 
		<p>The university was established in 2011 and began academic activities at undergraduate level in six departments under four faculties on 24 January 2012. The university offers degrees at undergraduate and postgraduate levels. The university houses 25 academic departments under six faculties, where eighteen departments are currently providing postgraduate degrees. Every year almost 1,400 students are admitted to undergraduate programs in the university. The university started its academic activities at the temporary campus at Barishal Zilla School and then shifted to its permanent campus. The permanent suburban campus of 50 acres of the university is located in Barisal Sadar Upazila beside Dhaka-Patuakhali Highway on the bank of Kirtankhola river.</p>
		<h2>Location:</h2>
		<p>University of Barishal is situated in the district of Barishal under Barishal Division. It is located at Karnakathi on the eastern bank of the Kirtonkhola river beside the Barishal-Patuakhali highway about 2 kilometers from the center of Barishal City. The university campus is spread over 50 acres of land.</p>


		
<?php
	include "footer.php";
?>


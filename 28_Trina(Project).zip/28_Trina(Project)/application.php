<?php
	include "header.php";
	include "dbconnect.php";
	
	$sql="SELECT * FROM departments";
	$result=$conn->query($sql);
	
?>		
	<div class="apply">
		<h2 align="center">Apply Online</h2>
	    <form action="application_action.php" method="POST">
		
			<label>Applicant Name</label>
			<input type="text" name="name" placeholder=" Enter Your name....">
			<label>Phone</label>
			<input type="text" name="phone" placeholder="Enter Your Phone...">
			<label>Email</label>
			<input type="email" name="email" placeholder="Enter Your Email...">
			<label>Date Of Birth</label>
			<input type="date" name="dob" placeholder="Enter dob  ...">
			<label>Choose Department</label>
			<select name="departments">
			<?php
				while($row=$result->fetch_assoc()){
		echo '<option value="'.$row["name"] .'">'.$row["name"] .'</option>';
				}
			?>
			</select>

			<input type="submit" value="Submit">
		  </form>
	</div>
	
<?php
	include "footer.php";
?>


